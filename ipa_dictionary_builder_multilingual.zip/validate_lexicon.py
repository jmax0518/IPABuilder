"""Validate output lexicons without needing the G2P dependencies."""
import argparse
import json
import unicodedata
from pathlib import Path


def check_language(base: Path, output_dir: str, lang: str):
    folder = base / output_dir / lang
    lexicon = folder / "lexicon.txt"
    phones_file = folder / "phones.txt"
    if not lexicon.exists() or not phones_file.exists():
        raise FileNotFoundError(f"Missing lexicon or phones.txt in {folder}")
    lines = lexicon.read_text(encoding="utf-8").splitlines()
    declared = set(phones_file.read_text(encoding="utf-8").splitlines())
    found = set()
    seen = set()
    errors = []
    for n, line in enumerate(lines, 1):
        parts = line.split("\t")
        if len(parts) != 2:
            errors.append(f"line {n}: expected word<TAB>phones")
            continue
        word, ipa = parts
        if not word or not ipa.strip():
            errors.append(f"line {n}: empty word/pronunciation")
        if ipa.strip() != ipa or "  " in ipa:
            errors.append(f"line {n}: noncanonical phone whitespace")
        if word != unicodedata.normalize('NFC',word) or ipa != unicodedata.normalize('NFC',ipa):
            errors.append(f"line {n}: not Unicode NFC")
        if (word,ipa) in seen:
            errors.append(f"line {n}: duplicated pair")
        seen.add((word,ipa))
        for phone in ipa.split():
            if phone in {"ˈ", "ˌ"}:
                errors.append(f"line {n}: stress mark is not attached to a phone")
            found.add(phone)
    if found != declared:
        errors.append(f"phone inventory mismatch, missing={found-declared}, extra={declared-found}")
    if errors:
        raise ValueError(f"{lang}: " + "; ".join(errors[:20]))
    return len(lines), len(declared)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="config.json")
    p.add_argument("--lang", default="all")
    args = p.parse_args()
    cfg_path = Path(args.config).resolve()
    config = json.loads(cfg_path.read_text(encoding="utf-8"))
    langs = config["languages"] if args.lang == "all" else {args.lang:config["languages"][args.lang]}
    for lang in langs:
        n, p = check_language(cfg_path.parent, config.get('output_dir','output'), lang)
        print(f"PASS {lang}: {n} pronunciations, {p} distinct phone tokens")

if __name__ == '__main__':
    main()
