"""Read text, CSV/TSV and JSONL corpora, without silently translating text."""
import csv
import json
from pathlib import Path
from typing import Iterator


def read_corpus(path: Path, field: str = "text") -> Iterator[str]:
    if not path.exists():
        raise FileNotFoundError(f"Corpus does not exist: {path}")
    ext = path.suffix.lower()
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        if ext == ".txt":
            for line in f:
                if line.strip():
                    yield line.strip()
        elif ext in {".csv", ".tsv"}:
            reader = csv.DictReader(f, delimiter="\t" if ext == ".tsv" else ",")
            if not reader.fieldnames or field not in reader.fieldnames:
                raise ValueError(f"Column {field!r} missing from {path}")
            for row in reader:
                value = row.get(field)
                if value and value.strip():
                    yield value.strip()
        elif ext == ".jsonl":
            for lineno, line in enumerate(f, 1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Invalid JSON at {path}:{lineno}") from exc
                if not isinstance(row, dict):
                    raise ValueError(f"Expected object at {path}:{lineno}")
                value = row.get(field)
                if value is None:
                    continue
                if not isinstance(value, str):
                    raise ValueError(f"Field {field!r} must be text at {path}:{lineno}")
                if value.strip():
                    yield value.strip()
        else:
            raise ValueError(f"Unsupported corpus format {ext!r}. Use .txt, .csv, .tsv or .jsonl")
