"""IPA bootstrap through eSpeak NG / Phonemizer."""
import re
import unicodedata


def clean_ipa(raw: str) -> str:
    """Preserve IPA sequences emitted as individual phone tokens.

    Attach standalone stress marks to following phone, so they do not
    mistakenly become independent 'phones'. Tone diacritics are retained.
    """
    raw = unicodedata.normalize("NFC", raw)
    parts = re.sub(r"\s+", " ", raw).strip().split(" ")
    result = []
    prefix = ""
    for part in parts:
        if not part:
            continue
        if part in {"ˈ", "ˌ"}:
            prefix += part
            continue
        result.append(prefix + part)
        prefix = ""
    if prefix:
        # Deliberately surface dangling stress instead of silently losing it.
        raise ValueError(f"IPA output ended with a stress mark: {raw!r}")
    return " ".join(result)


def generate_ipa(words, voice: str, with_stress: bool, njobs=1):
    """One IPA token string per input word, preserving input order."""
    if not words:
        return []
    try:
        from phonemizer import phonemize
        from phonemizer.separator import Separator
    except ImportError as exc:
        raise RuntimeError("Install dependencies: pip install -r requirements.txt") from exc

    try:
        result = phonemize(
            words, language=voice, backend="espeak",
            separator=Separator(phone=" ", word="", syllable=""),
            strip=True, preserve_punctuation=False, with_stress=with_stress,
            language_switch="remove-flags", njobs=njobs,
        )
    except Exception as exc:
        raise RuntimeError(
            f"Phonemizer failed for voice {voice!r}. Check 'espeak-ng --voices' "
            "and install eSpeak NG (not just the Python package)."
        ) from exc
    if isinstance(result, str):
        result = [result]
    if len(result) != len(words):
        raise RuntimeError(f"G2P returned {len(result)} lines for {len(words)} words")
    return [clean_ipa(x) for x in result]
