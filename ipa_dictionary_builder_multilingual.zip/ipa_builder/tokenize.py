"""Language-aware vocabulary extraction. Korean uses eojeol units, not morphemes."""
import re
import unicodedata
from collections import Counter
from typing import Iterable

ENGLISH_WORD = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)*|\d+", flags=re.UNICODE)
KOREAN_EOJEOL = re.compile(r"[^\W_]+(?:['’][^\W_]+)*", flags=re.UNICODE)
WHITESPACE_WORD = re.compile(r"[^\W_]+(?:['’][^\W_]+)*", flags=re.UNICODE)


def normalize_token(token: str, language: str) -> str:
    token = unicodedata.normalize("NFC", token.strip())
    token = token.replace('’', "'")
    if language in {"en", "es", "fr", "de", "pt", "it"}:
        token = token.casefold()
    return token


def is_word(token: str, keep_numbers: bool) -> bool:
    if not token:
        return False
    if not keep_numbers and any(c.isdigit() for c in token):
        return False
    return any(c.isalpha() for c in token)


def tokenize_line(text: str, language: str, method: str, keep_numbers: bool = False):
    text = unicodedata.normalize("NFC", text)
    if method == "english":
        raw = ENGLISH_WORD.findall(text)
    elif method == "korean_eojeol":
        # Each Hangul space-delimited eojeol is a unit. For Korean,
        # a dictionary of eojeol != a morphological base-word lexicon.
        raw = KOREAN_EOJEOL.findall(text)
    elif method == "jieba":
        try:
            import jieba
        except ImportError as exc:
            raise RuntimeError("Chinese tokenizer requires 'pip install jieba'") from exc
        raw = (part.strip() for part in jieba.cut(text, cut_all=False, HMM=True))
    elif method == "whitespace":
        raw = WHITESPACE_WORD.findall(text)
    else:
        raise ValueError(f"Unknown tokenizer {method!r}")
    for piece in raw:
        token = normalize_token(piece, language)
        if is_word(token, keep_numbers):
            yield token


def count_vocabulary(lines: Iterable[str], language: str, method: str, keep_numbers=False):
    counts = Counter()
    for line in lines:
        counts.update(tokenize_line(line, language, method, keep_numbers))
    return counts
