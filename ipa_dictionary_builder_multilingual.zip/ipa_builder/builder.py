"""Build separated word/IPA lexicons for each configured language."""
import json
import csv
from pathlib import Path
from .corpus import read_corpus
from .tokenize import count_vocabulary
from .lexicon import read_overrides, phone_inventory
from .g2p import generate_ipa


def batch_items(items, count):
    for i in range(0, len(items), count):
        yield items[i:i + count]


def write_tsv(path, header, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f, delimiter="\t", lineterminator="\n")
        if header:
            writer.writerow(header)
        writer.writerows(rows)


def build_language(config: dict, config_path: Path, language: str, g2p_func=generate_ipa):
    langs = config.get("languages", {})
    if language not in langs:
        raise ValueError(f"Language {language!r} not configured: {', '.join(langs)}")
    settings = langs[language]
    base = config_path.resolve().parent
    source = base / settings["source"]
    override_path = base / settings["overrides"]
    output_root = base / config.get("output_dir", "output") / language
    output_root.mkdir(parents=True, exist_ok=True)

    if settings["tokenizer"] == "jieba" and settings.get("custom_words"):
        import jieba
        user_dictionary = base / settings["custom_words"]
        if user_dictionary.exists():
            # Comment-only or empty dictionaries are valid.
            for line in user_dictionary.read_text(encoding="utf-8").splitlines():
                if line.strip() and not line.startswith("#"):
                    jieba.add_word(line.split()[0])

    corpus = read_corpus(source, settings.get("text_field", "text"))
    counts = count_vocabulary(corpus, language, settings["tokenizer"],
                              config.get("keep_numbers", False))
    overrides = read_overrides(override_path, language)

    vocabulary = sorted(counts, key=lambda w: (-counts[w], w))
    write_tsv(output_root / "vocabulary.tsv", ["word", "frequency"],
              [(w, counts[w]) for w in vocabulary])

    to_generate = sorted(w for w in counts if w not in overrides)
    generated = {}
    for batch in batch_items(to_generate, max(1, int(config.get("batch_size", 300)))):
        values = g2p_func(batch, settings["voice"],
                          settings.get("with_stress", False),
                          njobs=int(config.get("njobs", 1)))
        if len(values) != len(batch):
            raise RuntimeError(f"G2P returned wrong count for {language}")
        generated.update(zip(batch, values))

    write_tsv(output_root / "generated_raw.tsv", ["word", "ipa"],
              [(w, generated[w]) for w in sorted(generated)])

    entries = []
    missing = []
    review = []
    for word in vocabulary:
        if word in overrides:
            for pron in overrides[word]:
                entries.append((word, pron, "manual"))
        elif generated.get(word):
            entries.append((word, generated[word], "auto"))
            review.append((word, counts[word], generated[word], "auto_g2p_needs_review"))
        else:
            missing.append(word)
            review.append((word, counts[word], "", "no_pronunciation"))

    # Preserve multiple manually annotated pronunciations for homographs.
    write_tsv(output_root / "lexicon.txt", None,
              [(word, pron) for word, pron, _ in entries])
    write_tsv(output_root / "lexicon_with_source.tsv", ["word", "ipa", "source"], entries)
    write_tsv(output_root / "review_queue.tsv", ["word", "frequency", "ipa", "reason"], review)
    (output_root / "phones.txt").write_text(
        "".join(p + "\n" for p in phone_inventory(entries)), encoding="utf-8"
    )
    (output_root / "missing_words.txt").write_text(
        "".join(w + "\n" for w in missing), encoding="utf-8"
    )
    unused = sorted(set(overrides) - set(counts))
    (output_root / "unused_overrides.txt").write_text(
        "".join(w + "\n" for w in unused), encoding="utf-8"
    )

    stats = {
        "language":language, "description":settings.get("description", language),
        "voice":settings["voice"], "tokenizer":settings["tokenizer"],
        "vocabulary_size":len(counts), "lexicon_entries":len(entries),
        "manual_words":len(set(overrides) & set(counts)),
        "auto_words":sum(src == "auto" for _,_,src in entries),
        "missing_words":len(missing), "phone_types":len(phone_inventory(entries)),
        "unused_overrides":len(unused),
    }
    (output_root / "statistics.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return stats
