"""Manual review/override lexicon support."""
from collections import defaultdict
from pathlib import Path
from .g2p import clean_ipa
from .tokenize import normalize_token


def read_overrides(path: Path, language: str):
    result = defaultdict(list)
    if not path.exists():
        raise FileNotFoundError(f"Manual override file missing: {path}")
    for line_no, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "\t" not in line:
            raise ValueError(f"{path}:{line_no}: expected word<TAB>IPA phones")
        word, pron = line.split("\t", 1)
        word = normalize_token(word, language)
        pron = clean_ipa(pron)
        if not word or not pron:
            raise ValueError(f"{path}:{line_no}: empty word/IPA")
        if pron not in result[word]:
            result[word].append(pron)
    return dict(result)


def phone_inventory(rows):
    return sorted({phone for _, pron, _ in rows for phone in pron.split()})
