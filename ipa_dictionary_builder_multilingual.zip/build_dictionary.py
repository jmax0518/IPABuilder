"""Entry point: python build_dictionary.py --all / --lang zh / --lang ko."""
import argparse
import json
from pathlib import Path
from ipa_builder.builder import build_language

ALIASES = {"ch":"zh", "zh-cn":"zh", "cmn":"zh", "en-us":"en", "kr":"ko"}

def main():
    p = argparse.ArgumentParser(description="Create multilingual word-to-IPA ASR lexicons")
    p.add_argument("--config", default="config.json")
    sel = p.add_mutually_exclusive_group(required=True)
    sel.add_argument("--all", action="store_true")
    sel.add_argument("--lang", help="Language code: en, zh/ch, ko, ...")
    sel.add_argument("--list-languages", action="store_true")
    args = p.parse_args()
    config_file = Path(args.config).resolve()
    config = json.loads(config_file.read_text(encoding="utf-8"))
    langs = config["languages"]
    if args.list_languages:
        for code, s in langs.items():
            print(f"{code}: {s.get('description', code)}  (eSpeak voice: {s['voice']})")
        return
    selected = list(langs) if args.all else [ALIASES.get(args.lang, args.lang)]
    for lang in selected:
        stats = build_language(config, config_file, lang)
        print(f"[{lang}] vocabulary={stats['vocabulary_size']} "
              f"lexicon_entries={stats['lexicon_entries']} "
              f"phones={stats['phone_types']} missing={stats['missing_words']}")

if __name__ == "__main__":
    main()
