# Manual review and quality control

Every automatically generated pronunciation is an unverified suggestion.

- Open `output/<language>/review_queue.tsv`, which orders high-frequency words first.
- Check pronunciations against native speakers, audio or a reliable dictionary.
- Add corrections to `data/overrides_<language>.tsv` as `word<TAB>phone phone ...`.
- Multiple rows with the same word create pronunciation variants.
- Re-run `python build_dictionary.py --lang <language>`.
- The same text corpus never teaches G2P by itself; your reviewed entries are
  the supervised labels you would need for later G2P training.

Mandarin:
- Keep lexical tone distinctions and decide a consistent tone representation.
- A standalone word transcription may differ from how it sounds in context
  (tone sandhi, polyphonic characters). Validate in your intended domain.
- Jieba segmentation can be adjusted in `data/custom_zh_words.txt`.

Korean:
- The baseline output lexicon maps *eojeol* units separated by spaces,
  not morphological lemma/stems.
- Pronunciation varies across morpheme and word boundaries. Validate batchim,
  liaison and assimilation carefully; some pronunciation rules need context.
- For true lexical morpheme segmentation, integrate a Korean morphological analyzer
  such as Kiwi before building a morphological lexicon.

English:
- Pronunciations may differ by accent and grammatical context.
- Homographs such as 'read' should be stored with multiple pronunciations where needed.
