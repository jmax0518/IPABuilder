import json
from pathlib import Path
import pytest
from ipa_builder.tokenize import tokenize_line
from ipa_builder.corpus import read_corpus
from ipa_builder.builder import build_language
from ipa_builder.g2p import clean_ipa
from validate_lexicon import check_language


def test_english():
    assert list(tokenize_line("Hello, we're here!", "en", "english")) == ["hello", "we're", "here"]


def test_korean_eojeol():
    assert list(tokenize_line("안녕하세요. 오늘은 좋은 날입니다!", "ko", "korean_eojeol")) == ["안녕하세요", "오늘은", "좋은", "날입니다"]


def test_chinese_jieba():
    jieba = pytest.importorskip("jieba")
    result = list(tokenize_line("我喜欢学习中文。", "zh", "jieba"))
    assert "".join(result) == "我喜欢学习中文"
    assert len(result) >= 2


def test_stress_attach():
    assert clean_ipa("h ə l ˈ oʊ") == "h ə l ˈoʊ"


def test_corpus_reading(tmp_path):
    path = tmp_path/'a.jsonl'
    path.write_text('{"text":"hello"}\n{"text":"world"}\n', encoding='utf-8')
    assert list(read_corpus(path)) == ['hello', 'world']


def test_full_project_without_espeak(tmp_path):
    (tmp_path/'data').mkdir()
    (tmp_path/'data'/'en.txt').write_text('Hello world hello', encoding='utf-8')
    (tmp_path/'data'/'overrides_en.tsv').write_text('hello\th ə l oʊ\n', encoding='utf-8')
    cfg = {'output_dir':'output', 'languages':{'en':{
        'voice':'en-us', 'tokenizer':'english', 'source':'data/en.txt',
        'overrides':'data/overrides_en.tsv', 'with_stress':False}}}
    cfg_path = tmp_path/'config.json'
    cfg_path.write_text(json.dumps(cfg), encoding='utf-8')
    def fake_g2p(words, voice, with_stress, njobs=1):
        assert words == ['world']
        assert voice == 'en-us'
        return ['w ɝ l d']
    stats = build_language(cfg, cfg_path, 'en', g2p_func=fake_g2p)
    assert stats['vocabulary_size'] == 2
    lex = (tmp_path/'output'/'en'/'lexicon.txt').read_text(encoding='utf-8')
    assert 'hello\th ə l oʊ' in lex
    assert 'world\tw ɝ l d' in lex
    assert check_language(tmp_path,'output','en') == (2, 7)


def test_multiple_lexicon_variants(tmp_path):
    (tmp_path/'data').mkdir()
    (tmp_path/'data'/'ko.txt').write_text('읽다 읽다', encoding='utf-8')
    (tmp_path/'data'/'overrides_ko.tsv').write_text('읽다\ti k t a\n읽다\ti k̚ t a\n', encoding='utf-8')
    cfg={'languages':{'ko':{'voice':'ko','tokenizer':'korean_eojeol',
        'source':'data/ko.txt','overrides':'data/overrides_ko.tsv'}}}
    config_path=tmp_path/'config.json'
    config_path.write_text(json.dumps(cfg), encoding='utf-8')
    def not_called(*args, **kwargs):
        raise AssertionError('overridden word should not be phonemized')
    stats=build_language(cfg,config_path,'ko',g2p_func=not_called)
    assert stats['lexicon_entries']==2
